import { parseActivePathname } from '../../routes/url-parser.js';
import StoryDetailPresenter from './story-detail-presenter.js';

export default class StoryDetailPage {
  #presenter;

  async render() {
    return `
      <section class="container">
        <h2 class="section-title">Detail Cerita</h2>
        <div id="story-detail" class="story-detail"></div>

        <!-- Tombol kembali yang lebih rapi dan bisa ditata -->
        <div class="back-wrapper">
          <a href="#/" class="back-button">← Kembali ke Beranda</a>
        </div>
      </section>
    `;
  }

  async afterRender() {
    const { id } = parseActivePathname();
    this.#presenter = new StoryDetailPresenter(this);
    this.#presenter.showDetail(id);
  }

  displayStory(story) {
    const container = document.getElementById('story-detail');
    container.innerHTML = `
      <div class="story-image-wrapper">
        <img src="${story.photoUrl}" alt="Foto ${story.name}" class="story-detail-image" />
      </div>
      <h3>${story.name}</h3>
      <p>${story.description}</p>
      <p><small>Dibuat pada: ${new Date(story.createdAt).toLocaleString('id-ID')}</small></p>
    `;
  }

  displayError(message) {
    const container = document.getElementById('story-detail');
    container.innerHTML = `<p style="color:red;">${message}</p>`;
  }
}
